// parameter ADD = 3'b000;
// parameter ADC = 3'b001;
// parameter SUB = 3'b010;
// parameter SUBC = 3'b011;
// parameter AND = 3'b100;
// parameter XOR = 3'b101;
// parameter OR = 3'b110;
// parameter CMP = 3'b111;